<?php 

	include('include/connection.php');
	include('include/functions.php');

?>
<!DOCTYPE html>
<html>
	<head>
		<title> Intermediate CRUD Application (Dropdown, Radio) </title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
<body>

	<?php

		//Insert Data Here

		if (isset($_POST['create'])) {

			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$sex = $_POST['sex'];
			$departmentid = $_POST['departmentid'];

			$sql = "INSERT INTO tblemployees (firstname, lastname, sex, departmentid) ";
			$sql .= "VALUES (:firstname, :lastname, :sex, :departmentid) ";

			$stmt = $conn->prepare($sql);

			$stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
			$stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
			$stmt->bindParam(":sex", $sex, PDO::PARAM_STR);
			$stmt->bindParam(":departmentid", $departmentid, PDO::PARAM_INT);

			$stmt->execute();

			unset($_POST['create']);

		}

	?>
	<div id="wrapper">

		<form action="index.php" method="post">
			
			<fieldset>
				<legend> Add Record </legend>
				<div>
					<label for="firstname"> First Name </label>
					<input type="text" name="firstname" id="firstname" required>
				</div>
				<div>
					<label for="lastname"> Last Name </label>
					<input type="text" name="lastname" id="lastname" required>
				</div>
				<div>
					<label for="sex"> Sex </label>
					<p>
						<input type="radio" name="sex" value="Male" checked required><span> Male </span>
						<input type="radio" name="sex" value="Female" required><span> Female </span>
					</p>
				</div>
				<div>
					<label for="department"> Department </label>
					<select name="departmentid" id="departmentid" required>
						
						<?php 

							//The dropdown data will come from the database, not hard coded

							$sql = "SELECT * FROM tbldepartment ORDER BY department";
							echo bindDropdown($sql, 'departmentid', 'department');

						?>

					</select>
				</div>
				<div>
					<label for=""> &nbsp;</label>
					<input type="submit" value="CREATE" name="create">
				</div>

			</fieldset>
			
		</form>

		<hr>

		<?php

		// Read/Display Data
		
		$sql =  "SELECT * FROM tblemployees ";
		$sql .= "INNER JOIN tbldepartment ON ";
		$sql .= "tblemployees.departmentid = tbldepartment.departmentid ";
		$sql .= "ORDER BY lastname, firstname, department, sex ";

		$stmt = $conn->prepare($sql);
		$stmt->execute();

		$count = $stmt->rowCount();

		if ($count > 0) {

			echo "<table>";
				echo "<tr>";
					echo "<th> Last Name </th>";
					echo "<th> First Name </th>";
					echo "<th> Sex </th>";
					echo "<th> Department </th>";
					echo "<th colspan='2'> Action </th>";
			echo "</tr>";

			while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

				echo "<tr>";
					echo "<td>" . $result['lastname'] . "</td>";
					echo "<td>" . $result['firstname'] . "</td>";
					echo "<td>" . $result['sex'] . "</td>";
					echo "<td>" . $result['department'] . "</td>";
					echo "<td><a href='update.php?employeeid={$result['employeeid']}'> UPDATE </td>";
					echo "<td><a href='delete.php?employeeid={$result['employeeid']}'\" onclick=\"return confirm('Are you sure?')\"> DELETE </td>";
				echo "</tr>";

			}

			echo "</table>";

		}



		?>
	</div>

</body>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/main.js"></script>
</html>