<?php

	include('include/connection.php');
  
  $employeeid = $_GET['employeeid'];

  $sql = "DELETE FROM tblemployees WHERE employeeid = :employeeid";

  $stmt = $conn->prepare($sql);

  $stmt->bindParam(":employeeid", $employeeid, PDO::PARAM_STR);

  $stmt->execute();

  header("Location: index.php");
?>