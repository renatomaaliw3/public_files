<?php 

	include('../include/connection.php');
	include('../include/functions.php');

?>
<?php

	$employeeid = $_POST['employeeid'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$sex = $_POST['sex'];
	$departmentid = $_POST['departmentid'];
	$programid = $_POST['programid'];
		
	$sql =  "UPDATE tblemployees SET firstname = :firstname, lastname = :lastname, ";
	$sql .= "sex = :sex, departmentid = :departmentid, programid = :programid ";
	$sql .= "WHERE employeeid = :employeeid";

	$stmt = $conn->prepare($sql);

	$stmt->bindParam(":employeeid", $employeeid, PDO::PARAM_INT);
	$stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
	$stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
	$stmt->bindParam(":sex", $sex, PDO::PARAM_STR);
	$stmt->bindParam(":departmentid", $departmentid, PDO::PARAM_STR);
	$stmt->bindParam(":programid", $programid, PDO::PARAM_STR);

	$stmt->execute();

?>