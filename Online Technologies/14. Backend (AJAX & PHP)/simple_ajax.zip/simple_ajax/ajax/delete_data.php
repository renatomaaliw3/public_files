<?php

	// DELETE DATA
	include('../include/connection.php');
	include('../include/functions.php');

	$employeeid = $_POST['employeeid'];

	$sql = "DELETE FROM tblemployees WHERE employeeid = :employeeid";

	$stmt = $conn->prepare($sql);

	$stmt->bindParam(":employeeid", $employeeid, PDO::PARAM_STR);

	$stmt->execute();

?>