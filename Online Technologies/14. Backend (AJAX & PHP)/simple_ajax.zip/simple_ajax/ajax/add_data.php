<?php

	// ADD DATA
	include('../include/connection.php');
	include('../include/functions.php');

	//Insert Data Here

	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$sex = $_POST['sex'];
	$departmentid = $_POST['departmentid'];
	$programid = $_POST['programid'];

	$sql = "INSERT INTO tblemployees (firstname, lastname, sex, departmentid, programid) ";
	$sql .= "VALUES (:firstname, :lastname, :sex, :departmentid, :programid) ";
	
	$stmt = $conn->prepare($sql);

	$stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
	$stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
	$stmt->bindParam(":sex", $sex, PDO::PARAM_STR);
	$stmt->bindParam(":departmentid", $departmentid, PDO::PARAM_INT);
	$stmt->bindParam(":programid", $programid, PDO::PARAM_INT);

	$stmt->execute();

?>