var request = null;
$(document).ready(function() {

	//Load Create Form
  $('#formemployee').load('ajax/load_create_form.php');

  //Load Table Contents
  load_data();

  // Cascading Dropdown
  $('body').on('change', '#departmentid', function() {

    var departmentid = $(this).val();
    
    $.ajax({

      method: 'POST',
      url: 'ajax/load_program.php',
      data: {departmentid : departmentid},
      success: function(response) {

        $('#programid').html(response);
        $('#programid').prop('disabled', false);

      }

    });

  });

  // Search Bar
  $('#search').on('keyup', function() {

    var search = $(this).val();

    if (request) {

      clearTimeout(request);

    }

    request = setTimeout(function () {

      $.ajax({

        method: 'POST',
        url: 'ajax/load_search.php',
        data: {search : search},
        success: function(response) {

          $('#employee-table').html(response);
          request = null;

        }

      });

    }, 1000);

  });

  // Create Data
  $('body').on('submit', '#formemployee.create-form', function(event) {

    event.preventDefault(); //prevent form submission normal behavior
    var formData = $(this).serialize();

    $.ajax({

      type: 'POST',
      url: 'ajax/add_data.php',
      data: formData,
      success: function(response) {

        load_data();
        $('#formemployee').load('ajax_create_form.php');
        $('#search').val('').show();

      }

    });

  });

  // Update Data
  $('body').on('submit', '#formemployee.update-form', function(event){

    event.preventDefault(); //prevent form submission normal behavior
    var formData = $(this).serialize();

    $.ajax({

      type: 'POST',
      url: 'ajax/update_data.php',
      data: formData,
      success: function(response) {

        $('#live-search').show();
        $('#search').val('');
        $('#employee-table').show();
        $('#formemployee').load('ajax/load_create_form.php');
        $('#formemployee').removeClass('update-form').addClass('create-form');
        load_data();

      }

    });

  });

  // DELETE DATA
  $('body').on('click', '#delete', function(){

    var employeeid = $(this).attr('data-employeeid');

    if (confirm('Are you sure?')) {

      $.ajax({

        type: 'POST',
        url: 'ajax/delete_data.php',
        data: {employeeid : employeeid},
        success: function(response) {

          load_data();
          $('#search').val('').show();

        }        

      });

    }

  });

  // RETRIEVE UPDATE FORM

  $('body').on('click', '#update-form', function(){

    var employeeid = $(this).attr('data-employeeid');
    var departmentid = $(this).attr('data-departmentid');

    $.ajax({

      type: 'POST',
      url: 'ajax/load_update_form.php',
      data: {employeeid : employeeid, departmentid : departmentid},
      success: function(response) {

          $('#formemployee').removeClass('create-form').addClass('update-form');
          $('#live-search').hide();
          $('#employee-table').hide();
          $('#formemployee').html(response);

      }

    });

  });

  /* CUSTOM FUNCTION */

  function load_data() {

    $('#employee-table').load('ajax/load_table.php');

  }

});