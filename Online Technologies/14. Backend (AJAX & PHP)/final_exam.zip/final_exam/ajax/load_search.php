<?php

	// LOAD SEARCH
	include_once('../include/connection.php');
	include_once('../include/functions.php');

	// Insert Code Here
		
?>