<?php

	include_once('../include/connection.php');
	include_once('../include/functions.php');
	
	// Read Display Data
	
	// Insert Code Here

?>