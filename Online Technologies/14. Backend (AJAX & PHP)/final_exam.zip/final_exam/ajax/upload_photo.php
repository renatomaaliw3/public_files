<?php

	// ADD DATA
	include('../include/connection.php');
	include('../include/functions.php');

	$employeeid = $_POST['employeeid'];
	$oldphoto = $_POST['oldphoto'];

	//INSERT CODE HERE


?>