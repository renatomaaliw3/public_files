var request = null;
$(document).ready(function() {

	/* INSERT YOUR CODE HERE */

  



  /* CUSTOM FUNCTION */

  function load_data() {

    $('#employee-table').load('ajax/load_table.php');

  }

  function reset_form() {

		$('#formemployee')[0].reset();

	}

});