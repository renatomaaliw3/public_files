<?php include('connection.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title> Basic CRUD Application </title>
		<link rel="stylesheet" href="css/style.css">
	</head>
<body>

	<div id="wrapper">

		<?php 

	
			
		?>
		
	</div>

</body>
<script src="js/jquery.js"></script>
<script src="js/main.js"></script>
</html>